use TinkerBellDB

go

Create Procedure sp_UpdatePlayerMagicUser
begin
Update tblPlayer P inner join tblMagicUser M
SET PlayerName  PlayerSurname PlayerGender PlayerDateOfBrith
WHERE P.PlayerIDPK = M.MagicIDPK 
End


Create Procedure sp_InsertPlayerMagicUser
begin
INSERT INTO tblPlayer P inner join  tblMagicUser M
(@PlayerName varchar(50) , @PlayerSurname varchar(50) , @PlayerGender varchar(50) , @PlayerDateOfBirth varchar(50) , @MagicUserName varchar(50) , @Location varchar(50) , @Description varchar(50) , @Magictype varchar(50) , @MagicLevel varchar(50))
VALUES PlayerName , PlayerSurname , PlayerGender , PlayerDateOfBirth , MagicUserName , Location , Descriptio , MagicType , MagicLevel 
WHERE P.PlayerIDPK = M.MagicIDPK 
end