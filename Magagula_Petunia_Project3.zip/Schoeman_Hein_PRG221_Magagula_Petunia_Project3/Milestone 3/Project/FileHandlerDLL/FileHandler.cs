﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using HelperDLL;


namespace Project
{
    public class FileHandler
    {
        #region Fields
        //=======================================Fields========================================================================
        private FileStream stream;
        private StreamReader read;
        private StreamWriter write;
        private string filePath;
        //====================================================================================================================
        #endregion

        #region Constructors
        //==============================================Constructors=============================================================================
        public FileHandler(string filePathParam = "default.txt")
        {
            this.filePath = filePathParam;
        }

        public FileHandler()
        {

        }
        //========================================================================================================================================
        #endregion 

        #region Methods
        //=====================================================================Methods===========================================================

        /// <summary> WriteToTxtNew
        /// Writes to a text file that does not exist / already exists 
        /// </summary>
        /// <param name="unprocessedData">Carries the data that needs to be written to the text file </param>
        
        public void WriteToTxtNew(List<string> unprocessedData) 
        {
            try
            {
                filePath = "default.txt";
                stream = new FileStream(filePath,FileMode.OpenOrCreate,FileAccess.Write);
                write = new StreamWriter(stream);

                foreach (string item in unprocessedData)
                {
                    write.WriteLine(item);
                    write.Flush();
                }
            }
            catch (FileNotFoundException)
            {
                FileHandler handle = new FileHandler();
                handle.WriteToTxt(new List<string>() {"File not Found at {0}",filePath});
            }
            catch (DirectoryNotFoundException)
            {
                FileHandler handle = new FileHandler();
                handle.WriteToTxt(new List<string>() {"Directory not found for {0}",filePath});
            }
            catch (IOException)
            {
                FileHandler handle = new FileHandler();
                handle.WriteToTxt(new List<string>() {"Error fouund for {0}",filePath});
            }
            finally 
            {
                write.Close();
                stream.Close();
            }
        }

        /// <summary> WriteToTxt
        /// Writes to a text file that already exists 
        /// </summary>
        /// <param name="unprocessedData"> Carries the data that needs to be written to the text file </param>
        public void WriteToTxt(List<string> unprocessedData)
        {
            try
            {
                filePath = "default.txt";
                stream = new FileStream(filePath, FileMode.Append, FileAccess.Write);
                write = new StreamWriter(stream);

                foreach (string item in unprocessedData)
                {
                    write.WriteLine(item);
                    write.Flush();
                }
            }
            catch (FileNotFoundException)
            {
                FileHandler handle = new FileHandler();
                handle.WriteToTxt(new List<string>() { "File not Found at {0} : {1}", filePath });
            }
            catch (DirectoryNotFoundException)
            {
                FileHandler handle = new FileHandler();
                handle.WriteToTxt(new List<string>() { "Directory not found for: {0}", filePath });
            }
            catch (IOException)
            {
                FileHandler handle = new FileHandler();
                handle.WriteToTxt(new List<string>() { "Error found for : {0}", filePath });
            }
            finally
            {
                write.Close();
                stream.Close();
            }
        }
        
        /// <summary> ReadData
        /// Reads Data from text file and returns it
        /// </summary>
        /// <param name="filePath"> Contains the file's path / where its located </param>
        /// <returns> A list called Raw data </returns>
        public List<string> ReadDataFromFile(string filePath)
        {
            List<string> rawData = new List<string>();
            try
            {
                stream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                read = new StreamReader(stream);

                while (!read.EndOfStream)
                {
                    rawData.Add(read.ReadLine());
                }
            }
            catch (FileNotFoundException)
            {
                FileHandler handle = new FileHandler();
                handle.WriteToTxt(new List<string>() {"File not found at : {0}",filePath});
            }
            catch (DirectoryNotFoundException)
            {
                FileHandler handle = new FileHandler();
                handle.WriteToTxt(new List<string>() {"File not found at : {0}",filePath});
            }
            catch (IOException)
            {
                FileHandler handle = new FileHandler();
                handle.WriteToTxt(new List<string>() {"File not found at : {0}",filePath});
            }
            finally
            {
                //read.Close();
               // stream.Close();
            }

            return rawData;
        }


        public List<string> ReadData()
        {
            List<string> data = new List<string>();

            try
            {
                stream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                read = new StreamReader(stream);

                while (!read.EndOfStream)
                {
                    data.Add(read.ReadLine());
                }
            }
            catch (FileNotFoundException)
            {
                System.Windows.Forms.MessageBox.Show("File Not Found");
            }
            catch (DirectoryNotFoundException)
            {
                System.Windows.Forms.MessageBox.Show("Directory Not Found");
            }
            catch (IOException)
            {
                System.Windows.Forms.MessageBox.Show("Error");
            }
            finally
            {
                read.Close();
                stream.Close();
            }

            return data;
        }


        List<string> playerLoginInfo = new List<string>();
        bool isTrue;

        /// <summary> Login Attempt 
        /// The following method accepts the parameters and runs them through the text file to check if the user exists
        /// </summary>
        /// <param name="userName"> Passed on user name</param>
        /// <param name="passWord"> Passed on password</param>
        /// <returns>returns true value , if user exists  </returns>
        public bool LoginAttempt(string userName, string passWord) 
        {
            playerLoginInfo = ReadDataFromFile("Login.txt");

            foreach (string item in playerLoginInfo)
            {
                string[] fields = item.Split(',');
                if (userName == fields[0] && passWord == fields[1])
                {
                    isTrue = true;
                }
            }
            return isTrue;
        }

        //==========================================================================================================================================
        #endregion 
    }
}
