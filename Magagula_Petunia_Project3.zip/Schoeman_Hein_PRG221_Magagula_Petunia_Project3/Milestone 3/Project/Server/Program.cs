﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using HelperDLL;


namespace Server
{
    class Program
    {
        static List<Socket> connectedClients = new List<Socket>();
        static void Main(string[] args)
        {
            Socket serverSocket = new Socket(AddressFamily.InterNetwork,SocketType.Stream,ProtocolType.IP);
            serverSocket.Bind(new IPEndPoint(IPAddress.Parse("192.168.."),8000));

            serverSocket.Listen(50);

            Thread acceptThread = new Thread(new ParameterizedThreadStart(AcceptClient));
            acceptThread.Start(serverSocket);
        }

        public static void AcceptClient(object obj) 
        {
            Socket serverSocket = (Socket)obj;

            while (true)
            {
                Socket clientSocket = serverSocket.Accept();
                Thread recieverThread = new Thread(new ParameterizedThreadStart(RecieveData));
                recieverThread.Start(clientSocket);

                connectedClients.Add(clientSocket);
            }
        }

        public static void RecieveData(object obj) 
        {
            Socket clientSocket = (Socket)obj;
            object semaphore = new object();

            while (true)
            {
                byte[] buffer = new byte[1024];
                clientSocket.Receive(buffer);

                MessageClass message = (MessageClass)buffer.BinaryDeSerializer();
                FileHandler fHandler = new FileHandler("ClientInput");

                lock (semaphore)
                {
                    fHandler.WriteToTxt(new List<string>() { message.ToString() });
                }

                List<string> rawData = new List<string>();
                fHandler = new FileHandler("ClientInput");

                lock (semaphore)
                {
                    rawData = fHandler.ReadData();
                }

                List<MessageClass> messageList = new List<MessageClass>();

                lock (semaphore)
                {
                    foreach (string item in rawData)
                    {
                        string[] fields = item.Split(',');
                        messageList.Add(new MessageClass(fields[0], new MagicUser()));
                    }
                }

                lock (semaphore)
                {
                    foreach (MessageClass item in messageList)
                    {
                        foreach (Socket tempSocket in connectedClients)
                        {
                            tempSocket.Send(item.BinarySerializer());
                        }
                    }
                }

            }
        }
    }
}
