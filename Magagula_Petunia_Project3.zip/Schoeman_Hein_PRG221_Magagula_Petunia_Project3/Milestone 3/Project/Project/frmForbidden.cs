﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Project
{
    public partial class frmForbidden : Form
    {
        public frmForbidden()
        {
            InitializeComponent();
        }

        private void btnTrans_Click(object sender, EventArgs e)
        {
            Trans transForm = new Trans();
            this.Hide();
            transForm.Show();
        }

        private void exploreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExplore explore = new frmExplore();
            this.Hide();
            explore.Show();
        }

        private void adminToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAdmin admin = new frmAdmin();
            this.Hide();
            admin.Show();
        }

        private void homeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmWelcome home = new frmWelcome();
            this.Hide();
            home.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void btnBlood_Click(object sender, EventArgs e)
        {
            Blood bloodform = new Blood();
            this.Hide();
            bloodform.Show();
        }

        private void btnNecromancy_Click(object sender, EventArgs e)
        {
            Necro necromancy = new Necro();
            this.Hide();
            necromancy.Show();
        }
    }
}
