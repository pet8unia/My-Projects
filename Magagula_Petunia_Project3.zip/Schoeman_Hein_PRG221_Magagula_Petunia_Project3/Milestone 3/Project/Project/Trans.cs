﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Project
{
    public partial class Trans : Form
    {
        public Trans()
        {
            InitializeComponent();
        }

        private void btnLeave_Click(object sender, EventArgs e)
        {
            frmForbidden forbid = new frmForbidden();
            this.Hide();
            forbid.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You do not have enough bounty to hunt other sorceres", "Rookie", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
}
