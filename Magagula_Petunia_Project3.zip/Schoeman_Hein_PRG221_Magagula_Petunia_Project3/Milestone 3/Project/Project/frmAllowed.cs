﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Project
{
    public partial class frmAllowed : Form
    {
        public frmAllowed()
        {
            InitializeComponent();
        }

        private void btnHerb_Click(object sender, EventArgs e)
        {
            Herb herb = new Herb();
            this.Hide();
            herb.Show();
        }

        private void btnSummon_Click(object sender, EventArgs e)
        {
            Summ summon = new Summ();
            this.Hide();
            summon.Show();
        }

        private void btnAlchemy_Click(object sender, EventArgs e)
        {
            Alchemy alchemy = new Alchemy();
            this.Hide();
            alchemy.Show();
        }

        private void btnArcane_Click(object sender, EventArgs e)
        {
            Arcane arcane = new Arcane();
            this.Hide();
            arcane.Show();

        }

        private void btnNature_Click(object sender, EventArgs e)
        {
            Nature nature = new Nature();
            this.Hide();
            nature.Show();
        }

        private void exploreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExplore explore = new frmExplore();
            this.Hide();
            explore.Show();
        }

        private void adminToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAdmin admin = new frmAdmin();
            this.Hide();
            admin.Show();
        }

        private void homeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmWelcome welcome = new frmWelcome();
            this.Hide();
            welcome.Show();
        }
    }
}
