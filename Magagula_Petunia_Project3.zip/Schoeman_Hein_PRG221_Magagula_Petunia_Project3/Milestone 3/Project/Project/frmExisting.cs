﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Threading.Tasks;

namespace Project
{
    public partial class frmExisting : Form
    {
        // Petunia 
        Thread colorChange;
        object semaphore = new object();
        volatile bool continueThread = true;
 
        public frmExisting()
        {
            InitializeComponent();
            colorChange = new Thread(new ThreadStart(ChangeColor));
        }

        private void ChangeColor() 
        {
            
                lock (semaphore)
                {
                    label1.ForeColor = Color.Cyan;
                    Thread.Sleep(500);
                    label1.ForeColor = Color.White; 
                }
          
        }

        private void frmExisting_MouseHover(object sender, EventArgs e)
        {

        }

        private void label1_MouseUp(object sender, MouseEventArgs e)
        {
            
        }

        private void label1_MouseDown(object sender, MouseEventArgs e)
        {
            
        }

        private void label1_MouseMove(object sender, MouseEventArgs e)
        {
            
        }

        private void label1_MouseHover(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
          

            //if (colorChange.ThreadState != ThreadState.Suspended)
            //{
            //    colorChange.Suspend();
            //}    


            frmEditExisting editInfo = new frmEditExisting();
            this.Hide();
            editInfo.Show();
        }

        private void button2_MouseHover(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {  

            frmExplore exploreForm = new frmExplore();
            this.Hide();
            exploreForm.Show();
        }

        private void btnMagicLodge_MouseHover(object sender, EventArgs e)
        {
          
        }

        private void frmExisting_Load(object sender, EventArgs e)
        {
            continueThread = true;

            if (colorChange.ThreadState != ThreadState.Suspended)
            {
                colorChange.Start();
            }
            else
            {
                colorChange.Resume();
            }
            
        }

        private void adminToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAdmin admin = new frmAdmin();
            this.Hide();
            admin.Show();
        }

        private void homeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmWelcome home = new frmWelcome();
            this.Hide();
            home.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }
    }
}
