﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using HelperDLL;

namespace Project
{
    public partial class frmRegister : Form
    {
        public frmRegister()
        {
            InitializeComponent();
        }

        double bounty = 0;

        MagicUser magicUser = new MagicUser();

        private void backToolStripMenuItem_Click(object sender, EventArgs e)
        {
            

        }

        private void backToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void adminToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAdmin adminForm = new frmAdmin();
            this.Hide();
            adminForm.Show();
        }

        private void welcomePageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmWelcome welcome = new frmWelcome();
            this.Hide();
            welcome.Show();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void frmRegister_Load(object sender, EventArgs e)
        {

        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            //=====================Personal Details====================================================================================
            magicUser.Name = txtPName.Text; 
            magicUser.Surname = txtPSurname.Text;
            magicUser.Dob = txtDOB.Text;
   
            if (rgpFemale.Checked)
            {
                magicUser.Gender = "Female";
            }
            else 
            {
                magicUser.Gender = "Male";
            }

            //===================Magic Details==============================================================================================
            string magicName = txtMagicName.Text; 
            magicUser.MagicUserName = magicName;

            //===================Magic Level================================================================================================

            //==============Determines character Description=================================================================================
            if (rgpPixie.Checked)
            {
                magicUser.Description = "Pixie";
            }
            if (rgpFairy.Checked)
            {
                magicUser.Description = "Fairy";
            }
            if (rgpGoddess.Checked)
            {
                magicUser.Description = "Goddess";
            }
            if (rgpGnome.Checked)
            {
                magicUser.Description = "Gnome";
            }
            if (rgpTroll.Checked)
            {
                magicUser.Description = "Troll";
            }
            if (rgpWizard.Checked)
            {
                magicUser.Description = "Wizard"; 
            }

            //===============Determines magic type============================================================================
            if (rgpElemental.Checked)
            {
                magicUser.MagicType = "Elemental";
            }
            if (rgpHerb.Checked)
            {
                magicUser.MagicType = "Herbalist";
            }
            if (rgpNat.Checked)
            {
                magicUser.MagicType = "Nature";
            }
            if (rgpArcane.Checked)
            {
                magicUser.MagicType = "Arcane";
            }
            if (rgpBlood.Checked)
            {
                magicUser.MagicType = "Blood Magic";
                bounty = 50000;
                MessageBox.Show("You automatically recieve R50000 bounty", "Blood Magic", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            if (rgpSummon.Checked)
            {
                magicUser.MagicType = "Summoning";
                bounty = 50000;
                MessageBox.Show("You automatically recieve R50000 bounty", "Summoning", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            if (rgpNecro.Checked)
            {
                magicUser.MagicType = "Necromancy";
                bounty = 50000;
                MessageBox.Show("You automatically recieve R50000 bounty", "Necromancy", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            if (rgpAlchemy.Checked)
            {
                magicUser.MagicType = "Alchemy";
                bounty = 50000;
                MessageBox.Show("You automatically recieve R50000 bounty", "Alchemy", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            if (rgpTrans.Checked)
            {
                magicUser.MagicType = "Transmorgrify";
                bounty = 50000;
                MessageBox.Show("You automatically recieve R50000 bounty", "Transmorgfify", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        //========================================================================================================================
            
            magicUser.InsertMagicPlayer();

        //========================Username & Password generated and stored to textfile============================================
            Login login = new Login();
            MessageBox.Show(string.Format("Congradulations {0} You are now registered . Welcome to the adventures of Tinkerbell. {1}",magicName,login.GenerateUsernameANDPassword(txtPName.Text,txtPSurname.Text)),"",MessageBoxButtons.OK,MessageBoxIcon.Information);

            frmExplore explore = new frmExplore();
            this.Hide();
            explore.Show();
        }

        private void grpMagicLevel_MouseHover(object sender, EventArgs e)
        {
            MessageBox.Show("Due to you being a new user , you must start at Novice Level","Sorry !",MessageBoxButtons.OK,MessageBoxIcon.Information);
        }
    }
}
