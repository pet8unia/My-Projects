﻿namespace Project
{
    partial class frmRegister
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.grpMagicLevel = new System.Windows.Forms.GroupBox();
            this.rgpMaster = new System.Windows.Forms.RadioButton();
            this.rgpAdapt = new System.Windows.Forms.RadioButton();
            this.rgpNovice = new System.Windows.Forms.RadioButton();
            this.grpMagicType = new System.Windows.Forms.GroupBox();
            this.rgpBlood = new System.Windows.Forms.RadioButton();
            this.rgpNecro = new System.Windows.Forms.RadioButton();
            this.rgpTrans = new System.Windows.Forms.RadioButton();
            this.rgpAlchemy = new System.Windows.Forms.RadioButton();
            this.rgpNat = new System.Windows.Forms.RadioButton();
            this.rgpHerb = new System.Windows.Forms.RadioButton();
            this.rgpArcane = new System.Windows.Forms.RadioButton();
            this.rgpSummon = new System.Windows.Forms.RadioButton();
            this.rgpElemental = new System.Windows.Forms.RadioButton();
            this.grpCharacter = new System.Windows.Forms.GroupBox();
            this.rgpWizard = new System.Windows.Forms.RadioButton();
            this.rgpTroll = new System.Windows.Forms.RadioButton();
            this.rgpGnome = new System.Windows.Forms.RadioButton();
            this.rgpGoddess = new System.Windows.Forms.RadioButton();
            this.rgpFairy = new System.Windows.Forms.RadioButton();
            this.rgpPixie = new System.Windows.Forms.RadioButton();
            this.txtMagicName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.backToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.backToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.adminToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.welcomePageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.rgpMale = new System.Windows.Forms.RadioButton();
            this.rgpFemale = new System.Windows.Forms.RadioButton();
            this.grpGender = new System.Windows.Forms.GroupBox();
            this.txtPName = new System.Windows.Forms.TextBox();
            this.txtDOB = new System.Windows.Forms.TextBox();
            this.txtPSurname = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnProcess = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.grpMagicLevel.SuspendLayout();
            this.grpMagicType.SuspendLayout();
            this.grpCharacter.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.grpGender.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(466, 52);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(579, 446);
            this.panel1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.pictureBox1.BackgroundImage = global::Project.Properties.Resources.tink;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(412, 21);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(152, 399);
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.grpMagicLevel);
            this.groupBox3.Controls.Add(this.grpMagicType);
            this.groupBox3.Controls.Add(this.grpCharacter);
            this.groupBox3.Controls.Add(this.txtMagicName);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox3.Location = new System.Drawing.Point(13, 10);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(393, 410);
            this.groupBox3.TabIndex = 10;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Magical Character";
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // grpMagicLevel
            // 
            this.grpMagicLevel.Controls.Add(this.rgpMaster);
            this.grpMagicLevel.Controls.Add(this.rgpAdapt);
            this.grpMagicLevel.Controls.Add(this.rgpNovice);
            this.grpMagicLevel.Location = new System.Drawing.Point(13, 144);
            this.grpMagicLevel.Name = "grpMagicLevel";
            this.grpMagicLevel.Size = new System.Drawing.Size(99, 117);
            this.grpMagicLevel.TabIndex = 15;
            this.grpMagicLevel.TabStop = false;
            this.grpMagicLevel.Text = "Magic Level";
            this.grpMagicLevel.MouseHover += new System.EventHandler(this.grpMagicLevel_MouseHover);
            // 
            // rgpMaster
            // 
            this.rgpMaster.AutoSize = true;
            this.rgpMaster.Enabled = false;
            this.rgpMaster.Location = new System.Drawing.Point(16, 80);
            this.rgpMaster.Name = "rgpMaster";
            this.rgpMaster.Size = new System.Drawing.Size(63, 19);
            this.rgpMaster.TabIndex = 2;
            this.rgpMaster.TabStop = true;
            this.rgpMaster.Text = "Master";
            this.rgpMaster.UseVisualStyleBackColor = true;
            // 
            // rgpAdapt
            // 
            this.rgpAdapt.AutoSize = true;
            this.rgpAdapt.Enabled = false;
            this.rgpAdapt.Location = new System.Drawing.Point(16, 55);
            this.rgpAdapt.Name = "rgpAdapt";
            this.rgpAdapt.Size = new System.Drawing.Size(56, 19);
            this.rgpAdapt.TabIndex = 1;
            this.rgpAdapt.TabStop = true;
            this.rgpAdapt.Text = "Adapt";
            this.rgpAdapt.UseVisualStyleBackColor = true;
            // 
            // rgpNovice
            // 
            this.rgpNovice.AutoSize = true;
            this.rgpNovice.Location = new System.Drawing.Point(16, 30);
            this.rgpNovice.Name = "rgpNovice";
            this.rgpNovice.Size = new System.Drawing.Size(62, 19);
            this.rgpNovice.TabIndex = 0;
            this.rgpNovice.TabStop = true;
            this.rgpNovice.Text = "Novice";
            this.rgpNovice.UseVisualStyleBackColor = true;
            // 
            // grpMagicType
            // 
            this.grpMagicType.Controls.Add(this.rgpBlood);
            this.grpMagicType.Controls.Add(this.rgpNecro);
            this.grpMagicType.Controls.Add(this.rgpTrans);
            this.grpMagicType.Controls.Add(this.rgpAlchemy);
            this.grpMagicType.Controls.Add(this.rgpNat);
            this.grpMagicType.Controls.Add(this.rgpHerb);
            this.grpMagicType.Controls.Add(this.rgpArcane);
            this.grpMagicType.Controls.Add(this.rgpSummon);
            this.grpMagicType.Controls.Add(this.rgpElemental);
            this.grpMagicType.Location = new System.Drawing.Point(13, 283);
            this.grpMagicType.Name = "grpMagicType";
            this.grpMagicType.Size = new System.Drawing.Size(365, 115);
            this.grpMagicType.TabIndex = 14;
            this.grpMagicType.TabStop = false;
            this.grpMagicType.Text = "Magic Type";
            // 
            // rgpBlood
            // 
            this.rgpBlood.AutoSize = true;
            this.rgpBlood.Location = new System.Drawing.Point(219, 28);
            this.rgpBlood.Name = "rgpBlood";
            this.rgpBlood.Size = new System.Drawing.Size(94, 19);
            this.rgpBlood.TabIndex = 11;
            this.rgpBlood.TabStop = true;
            this.rgpBlood.Text = "Blood Magic";
            this.rgpBlood.UseVisualStyleBackColor = true;
            // 
            // rgpNecro
            // 
            this.rgpNecro.AutoSize = true;
            this.rgpNecro.Location = new System.Drawing.Point(219, 53);
            this.rgpNecro.Name = "rgpNecro";
            this.rgpNecro.Size = new System.Drawing.Size(94, 19);
            this.rgpNecro.TabIndex = 10;
            this.rgpNecro.TabStop = true;
            this.rgpNecro.Text = "Necromancy";
            this.rgpNecro.UseVisualStyleBackColor = true;
            // 
            // rgpTrans
            // 
            this.rgpTrans.AutoSize = true;
            this.rgpTrans.Location = new System.Drawing.Point(219, 78);
            this.rgpTrans.Name = "rgpTrans";
            this.rgpTrans.Size = new System.Drawing.Size(100, 19);
            this.rgpTrans.TabIndex = 9;
            this.rgpTrans.TabStop = true;
            this.rgpTrans.Text = "Transmorgrify";
            this.rgpTrans.UseVisualStyleBackColor = true;
            // 
            // rgpAlchemy
            // 
            this.rgpAlchemy.AutoSize = true;
            this.rgpAlchemy.Location = new System.Drawing.Point(112, 78);
            this.rgpAlchemy.Name = "rgpAlchemy";
            this.rgpAlchemy.Size = new System.Drawing.Size(71, 19);
            this.rgpAlchemy.TabIndex = 8;
            this.rgpAlchemy.TabStop = true;
            this.rgpAlchemy.Text = "Alchemy";
            this.rgpAlchemy.UseVisualStyleBackColor = true;
            // 
            // rgpNat
            // 
            this.rgpNat.AutoSize = true;
            this.rgpNat.Location = new System.Drawing.Point(112, 53);
            this.rgpNat.Name = "rgpNat";
            this.rgpNat.Size = new System.Drawing.Size(62, 19);
            this.rgpNat.TabIndex = 7;
            this.rgpNat.TabStop = true;
            this.rgpNat.Text = "Nature";
            this.rgpNat.UseVisualStyleBackColor = true;
            // 
            // rgpHerb
            // 
            this.rgpHerb.AutoSize = true;
            this.rgpHerb.Location = new System.Drawing.Point(112, 28);
            this.rgpHerb.Name = "rgpHerb";
            this.rgpHerb.Size = new System.Drawing.Size(74, 19);
            this.rgpHerb.TabIndex = 6;
            this.rgpHerb.TabStop = true;
            this.rgpHerb.Text = "Herbalist";
            this.rgpHerb.UseVisualStyleBackColor = true;
            // 
            // rgpArcane
            // 
            this.rgpArcane.AutoSize = true;
            this.rgpArcane.Location = new System.Drawing.Point(6, 78);
            this.rgpArcane.Name = "rgpArcane";
            this.rgpArcane.Size = new System.Drawing.Size(63, 19);
            this.rgpArcane.TabIndex = 5;
            this.rgpArcane.TabStop = true;
            this.rgpArcane.Text = "Arcane";
            this.rgpArcane.UseVisualStyleBackColor = true;
            // 
            // rgpSummon
            // 
            this.rgpSummon.AutoSize = true;
            this.rgpSummon.Location = new System.Drawing.Point(6, 53);
            this.rgpSummon.Name = "rgpSummon";
            this.rgpSummon.Size = new System.Drawing.Size(93, 19);
            this.rgpSummon.TabIndex = 3;
            this.rgpSummon.TabStop = true;
            this.rgpSummon.Text = "Summoning";
            this.rgpSummon.UseVisualStyleBackColor = true;
            // 
            // rgpElemental
            // 
            this.rgpElemental.AutoSize = true;
            this.rgpElemental.Location = new System.Drawing.Point(6, 28);
            this.rgpElemental.Name = "rgpElemental";
            this.rgpElemental.Size = new System.Drawing.Size(81, 19);
            this.rgpElemental.TabIndex = 4;
            this.rgpElemental.TabStop = true;
            this.rgpElemental.Text = "Elemental";
            this.rgpElemental.UseVisualStyleBackColor = true;
            // 
            // grpCharacter
            // 
            this.grpCharacter.Controls.Add(this.rgpWizard);
            this.grpCharacter.Controls.Add(this.rgpTroll);
            this.grpCharacter.Controls.Add(this.rgpGnome);
            this.grpCharacter.Controls.Add(this.rgpGoddess);
            this.grpCharacter.Controls.Add(this.rgpFairy);
            this.grpCharacter.Controls.Add(this.rgpPixie);
            this.grpCharacter.Location = new System.Drawing.Point(147, 159);
            this.grpCharacter.Name = "grpCharacter";
            this.grpCharacter.Size = new System.Drawing.Size(231, 101);
            this.grpCharacter.TabIndex = 13;
            this.grpCharacter.TabStop = false;
            this.grpCharacter.Text = "Character Type";
            // 
            // rgpWizard
            // 
            this.rgpWizard.AutoSize = true;
            this.rgpWizard.Location = new System.Drawing.Point(136, 69);
            this.rgpWizard.Name = "rgpWizard";
            this.rgpWizard.Size = new System.Drawing.Size(63, 19);
            this.rgpWizard.TabIndex = 8;
            this.rgpWizard.TabStop = true;
            this.rgpWizard.Text = "Wizard";
            this.rgpWizard.UseVisualStyleBackColor = true;
            // 
            // rgpTroll
            // 
            this.rgpTroll.AutoSize = true;
            this.rgpTroll.Location = new System.Drawing.Point(136, 44);
            this.rgpTroll.Name = "rgpTroll";
            this.rgpTroll.Size = new System.Drawing.Size(49, 19);
            this.rgpTroll.TabIndex = 7;
            this.rgpTroll.TabStop = true;
            this.rgpTroll.Text = "Troll";
            this.rgpTroll.UseVisualStyleBackColor = true;
            this.rgpTroll.CheckedChanged += new System.EventHandler(this.radioButton5_CheckedChanged);
            // 
            // rgpGnome
            // 
            this.rgpGnome.AutoSize = true;
            this.rgpGnome.Location = new System.Drawing.Point(136, 19);
            this.rgpGnome.Name = "rgpGnome";
            this.rgpGnome.Size = new System.Drawing.Size(66, 19);
            this.rgpGnome.TabIndex = 6;
            this.rgpGnome.TabStop = true;
            this.rgpGnome.Text = "Gnome";
            this.rgpGnome.UseVisualStyleBackColor = true;
            // 
            // rgpGoddess
            // 
            this.rgpGoddess.AutoSize = true;
            this.rgpGoddess.Location = new System.Drawing.Point(19, 69);
            this.rgpGoddess.Name = "rgpGoddess";
            this.rgpGoddess.Size = new System.Drawing.Size(74, 19);
            this.rgpGoddess.TabIndex = 3;
            this.rgpGoddess.TabStop = true;
            this.rgpGoddess.Text = "Goddess";
            this.rgpGoddess.UseVisualStyleBackColor = true;
            // 
            // rgpFairy
            // 
            this.rgpFairy.AutoSize = true;
            this.rgpFairy.Location = new System.Drawing.Point(19, 44);
            this.rgpFairy.Name = "rgpFairy";
            this.rgpFairy.Size = new System.Drawing.Size(51, 19);
            this.rgpFairy.TabIndex = 5;
            this.rgpFairy.TabStop = true;
            this.rgpFairy.Text = "Fairy";
            this.rgpFairy.UseVisualStyleBackColor = true;
            // 
            // rgpPixie
            // 
            this.rgpPixie.AutoSize = true;
            this.rgpPixie.Location = new System.Drawing.Point(18, 20);
            this.rgpPixie.Name = "rgpPixie";
            this.rgpPixie.Size = new System.Drawing.Size(52, 19);
            this.rgpPixie.TabIndex = 4;
            this.rgpPixie.TabStop = true;
            this.rgpPixie.Text = "Pixie";
            this.rgpPixie.UseVisualStyleBackColor = true;
            // 
            // txtMagicName
            // 
            this.txtMagicName.Location = new System.Drawing.Point(7, 100);
            this.txtMagicName.Name = "txtMagicName";
            this.txtMagicName.Size = new System.Drawing.Size(371, 21);
            this.txtMagicName.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 69);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(91, 15);
            this.label5.TabIndex = 9;
            this.label5.Text = "Magical Name:";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.backToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1057, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // backToolStripMenuItem
            // 
            this.backToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.backToolStripMenuItem1,
            this.exitToolStripMenuItem});
            this.backToolStripMenuItem.Name = "backToolStripMenuItem";
            this.backToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.backToolStripMenuItem.Text = "Options";
            this.backToolStripMenuItem.Click += new System.EventHandler(this.backToolStripMenuItem_Click);
            // 
            // backToolStripMenuItem1
            // 
            this.backToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.adminToolStripMenuItem,
            this.welcomePageToolStripMenuItem});
            this.backToolStripMenuItem1.Name = "backToolStripMenuItem1";
            this.backToolStripMenuItem1.Size = new System.Drawing.Size(99, 22);
            this.backToolStripMenuItem1.Text = "Back";
            this.backToolStripMenuItem1.Click += new System.EventHandler(this.backToolStripMenuItem1_Click);
            // 
            // adminToolStripMenuItem
            // 
            this.adminToolStripMenuItem.Name = "adminToolStripMenuItem";
            this.adminToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.adminToolStripMenuItem.Text = "Admin";
            this.adminToolStripMenuItem.Click += new System.EventHandler(this.adminToolStripMenuItem_Click);
            // 
            // welcomePageToolStripMenuItem
            // 
            this.welcomePageToolStripMenuItem.Name = "welcomePageToolStripMenuItem";
            this.welcomePageToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.welcomePageToolStripMenuItem.Text = "Welcome Page";
            this.welcomePageToolStripMenuItem.Click += new System.EventHandler(this.welcomePageToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(99, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Surname:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Date of Birth:";
            // 
            // rgpMale
            // 
            this.rgpMale.AutoSize = true;
            this.rgpMale.Location = new System.Drawing.Point(6, 28);
            this.rgpMale.Name = "rgpMale";
            this.rgpMale.Size = new System.Drawing.Size(48, 17);
            this.rgpMale.TabIndex = 3;
            this.rgpMale.TabStop = true;
            this.rgpMale.Text = "Male";
            this.rgpMale.UseVisualStyleBackColor = true;
            // 
            // rgpFemale
            // 
            this.rgpFemale.AutoSize = true;
            this.rgpFemale.Location = new System.Drawing.Point(6, 51);
            this.rgpFemale.Name = "rgpFemale";
            this.rgpFemale.Size = new System.Drawing.Size(59, 17);
            this.rgpFemale.TabIndex = 4;
            this.rgpFemale.TabStop = true;
            this.rgpFemale.Text = "Female";
            this.rgpFemale.UseVisualStyleBackColor = true;
            // 
            // grpGender
            // 
            this.grpGender.Controls.Add(this.rgpMale);
            this.grpGender.Controls.Add(this.rgpFemale);
            this.grpGender.Location = new System.Drawing.Point(267, 29);
            this.grpGender.Name = "grpGender";
            this.grpGender.Size = new System.Drawing.Size(77, 77);
            this.grpGender.TabIndex = 5;
            this.grpGender.TabStop = false;
            this.grpGender.Text = "Gender";
            this.grpGender.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // txtPName
            // 
            this.txtPName.Location = new System.Drawing.Point(103, 26);
            this.txtPName.Name = "txtPName";
            this.txtPName.Size = new System.Drawing.Size(138, 20);
            this.txtPName.TabIndex = 6;
            // 
            // txtDOB
            // 
            this.txtDOB.Location = new System.Drawing.Point(103, 82);
            this.txtDOB.Name = "txtDOB";
            this.txtDOB.Size = new System.Drawing.Size(138, 20);
            this.txtDOB.TabIndex = 7;
            // 
            // txtPSurname
            // 
            this.txtPSurname.Location = new System.Drawing.Point(103, 55);
            this.txtPSurname.Name = "txtPSurname";
            this.txtPSurname.Size = new System.Drawing.Size(138, 20);
            this.txtPSurname.TabIndex = 8;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.txtPSurname);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.txtDOB);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.txtPName);
            this.groupBox2.Controls.Add(this.grpGender);
            this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox2.Location = new System.Drawing.Point(25, 18);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(360, 130);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Personal Information";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Curlz MT", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(0, 38);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(460, 49);
            this.label4.TabIndex = 2;
            this.label4.Text = "Register yourself as a new user";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.groupBox2);
            this.panel2.Location = new System.Drawing.Point(12, 207);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(405, 156);
            this.panel2.TabIndex = 3;
            // 
            // btnProcess
            // 
            this.btnProcess.Location = new System.Drawing.Point(137, 439);
            this.btnProcess.Name = "btnProcess";
            this.btnProcess.Size = new System.Drawing.Size(151, 34);
            this.btnProcess.TabIndex = 4;
            this.btnProcess.Text = "Process";
            this.btnProcess.UseVisualStyleBackColor = true;
            this.btnProcess.Click += new System.EventHandler(this.btnProcess_Click);
            // 
            // frmRegister
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Project.Properties.Resources.wal;
            this.ClientSize = new System.Drawing.Size(1057, 510);
            this.Controls.Add(this.btnProcess);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmRegister";
            this.Text = "frmRegister";
            this.Load += new System.EventHandler(this.frmRegister_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.grpMagicLevel.ResumeLayout(false);
            this.grpMagicLevel.PerformLayout();
            this.grpMagicType.ResumeLayout(false);
            this.grpMagicType.PerformLayout();
            this.grpCharacter.ResumeLayout(false);
            this.grpCharacter.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.grpGender.ResumeLayout(false);
            this.grpGender.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem backToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtPSurname;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtDOB;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPName;
        private System.Windows.Forms.GroupBox grpGender;
        private System.Windows.Forms.RadioButton rgpMale;
        private System.Windows.Forms.RadioButton rgpFemale;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ToolStripMenuItem backToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adminToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem welcomePageToolStripMenuItem;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtMagicName;
        private System.Windows.Forms.GroupBox grpCharacter;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox grpMagicLevel;
        private System.Windows.Forms.RadioButton rgpMaster;
        private System.Windows.Forms.RadioButton rgpAdapt;
        private System.Windows.Forms.RadioButton rgpNovice;
        private System.Windows.Forms.GroupBox grpMagicType;
        private System.Windows.Forms.RadioButton rgpBlood;
        private System.Windows.Forms.RadioButton rgpNecro;
        private System.Windows.Forms.RadioButton rgpTrans;
        private System.Windows.Forms.RadioButton rgpAlchemy;
        private System.Windows.Forms.RadioButton rgpNat;
        private System.Windows.Forms.RadioButton rgpHerb;
        private System.Windows.Forms.RadioButton rgpArcane;
        private System.Windows.Forms.RadioButton rgpSummon;
        private System.Windows.Forms.RadioButton rgpElemental;
        private System.Windows.Forms.RadioButton rgpWizard;
        private System.Windows.Forms.RadioButton rgpTroll;
        private System.Windows.Forms.RadioButton rgpGnome;
        private System.Windows.Forms.RadioButton rgpGoddess;
        private System.Windows.Forms.RadioButton rgpFairy;
        private System.Windows.Forms.RadioButton rgpPixie;
        private System.Windows.Forms.Button btnProcess;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}