﻿namespace Project
{
    partial class frmAllowed
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnElement = new System.Windows.Forms.Button();
            this.btnHerb = new System.Windows.Forms.Button();
            this.btnSummon = new System.Windows.Forms.Button();
            this.btnAlchemy = new System.Windows.Forms.Button();
            this.btnArcane = new System.Windows.Forms.Button();
            this.btnNature = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.backToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exploreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adminToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.homeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnElement
            // 
            this.btnElement.Location = new System.Drawing.Point(82, 56);
            this.btnElement.Name = "btnElement";
            this.btnElement.Size = new System.Drawing.Size(229, 40);
            this.btnElement.TabIndex = 0;
            this.btnElement.Text = "Elemental";
            this.btnElement.UseVisualStyleBackColor = true;
            // 
            // btnHerb
            // 
            this.btnHerb.Location = new System.Drawing.Point(82, 116);
            this.btnHerb.Name = "btnHerb";
            this.btnHerb.Size = new System.Drawing.Size(229, 40);
            this.btnHerb.TabIndex = 1;
            this.btnHerb.Text = "Herbalist";
            this.btnHerb.UseVisualStyleBackColor = true;
            this.btnHerb.Click += new System.EventHandler(this.btnHerb_Click);
            // 
            // btnSummon
            // 
            this.btnSummon.Location = new System.Drawing.Point(82, 173);
            this.btnSummon.Name = "btnSummon";
            this.btnSummon.Size = new System.Drawing.Size(229, 40);
            this.btnSummon.TabIndex = 2;
            this.btnSummon.Text = "Summoning";
            this.btnSummon.UseVisualStyleBackColor = true;
            this.btnSummon.Click += new System.EventHandler(this.btnSummon_Click);
            // 
            // btnAlchemy
            // 
            this.btnAlchemy.Location = new System.Drawing.Point(82, 234);
            this.btnAlchemy.Name = "btnAlchemy";
            this.btnAlchemy.Size = new System.Drawing.Size(229, 40);
            this.btnAlchemy.TabIndex = 3;
            this.btnAlchemy.Text = "Alchemy";
            this.btnAlchemy.UseVisualStyleBackColor = true;
            this.btnAlchemy.Click += new System.EventHandler(this.btnAlchemy_Click);
            // 
            // btnArcane
            // 
            this.btnArcane.Location = new System.Drawing.Point(82, 291);
            this.btnArcane.Name = "btnArcane";
            this.btnArcane.Size = new System.Drawing.Size(229, 40);
            this.btnArcane.TabIndex = 4;
            this.btnArcane.Text = "Arcane";
            this.btnArcane.UseVisualStyleBackColor = true;
            this.btnArcane.Click += new System.EventHandler(this.btnArcane_Click);
            // 
            // btnNature
            // 
            this.btnNature.Location = new System.Drawing.Point(82, 349);
            this.btnNature.Name = "btnNature";
            this.btnNature.Size = new System.Drawing.Size(229, 40);
            this.btnNature.TabIndex = 5;
            this.btnNature.Text = "Nature";
            this.btnNature.UseVisualStyleBackColor = true;
            this.btnNature.Click += new System.EventHandler(this.btnNature_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(399, 24);
            this.menuStrip1.TabIndex = 6;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.backToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // backToolStripMenuItem
            // 
            this.backToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exploreToolStripMenuItem,
            this.adminToolStripMenuItem,
            this.homeToolStripMenuItem});
            this.backToolStripMenuItem.Name = "backToolStripMenuItem";
            this.backToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.backToolStripMenuItem.Text = "Back";
            // 
            // exploreToolStripMenuItem
            // 
            this.exploreToolStripMenuItem.Name = "exploreToolStripMenuItem";
            this.exploreToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.exploreToolStripMenuItem.Text = "Explore";
            this.exploreToolStripMenuItem.Click += new System.EventHandler(this.exploreToolStripMenuItem_Click);
            // 
            // adminToolStripMenuItem
            // 
            this.adminToolStripMenuItem.Name = "adminToolStripMenuItem";
            this.adminToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.adminToolStripMenuItem.Text = "Admin";
            this.adminToolStripMenuItem.Click += new System.EventHandler(this.adminToolStripMenuItem_Click);
            // 
            // homeToolStripMenuItem
            // 
            this.homeToolStripMenuItem.Name = "homeToolStripMenuItem";
            this.homeToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.homeToolStripMenuItem.Text = "Home";
            this.homeToolStripMenuItem.Click += new System.EventHandler(this.homeToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // frmAllowed
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Project.Properties.Resources._6606e27d76fed269e5f8637b5e0ac382;
            this.ClientSize = new System.Drawing.Size(399, 430);
            this.Controls.Add(this.btnNature);
            this.Controls.Add(this.btnArcane);
            this.Controls.Add(this.btnAlchemy);
            this.Controls.Add(this.btnSummon);
            this.Controls.Add(this.btnHerb);
            this.Controls.Add(this.btnElement);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmAllowed";
            this.Text = "frmAllowed";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnElement;
        private System.Windows.Forms.Button btnHerb;
        private System.Windows.Forms.Button btnSummon;
        private System.Windows.Forms.Button btnAlchemy;
        private System.Windows.Forms.Button btnArcane;
        private System.Windows.Forms.Button btnNature;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem backToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exploreToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adminToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem homeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
    }
}