﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Project
{
    public partial class frmEditExisting : Form
    {
        public frmEditExisting()
        {
            InitializeComponent();
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void frmEditExisting_Load(object sender, EventArgs e)
        {

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void adminToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAdmin adminForm = new frmAdmin();
            this.Hide();
            adminForm.Show();
        }

        private void welcomePageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmWelcome welcomeForm = new frmWelcome();
            this.Hide();
            welcomeForm.Show();
        }

        private void proceedToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExplore exploreForm = new frmExplore();
            this.Hide();
            exploreForm.Show();
        }
    }
}
