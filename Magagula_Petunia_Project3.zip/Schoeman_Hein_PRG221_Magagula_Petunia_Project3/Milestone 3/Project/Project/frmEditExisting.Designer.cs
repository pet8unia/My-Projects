﻿namespace Project
{
    partial class frmEditExisting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbcPersonal = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtPSurname = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtDOB = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPName = new System.Windows.Forms.TextBox();
            this.grpGender = new System.Windows.Forms.GroupBox();
            this.rgpMale = new System.Windows.Forms.RadioButton();
            this.rgpFemale = new System.Windows.Forms.RadioButton();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.rtxtDescription = new System.Windows.Forms.RichTextBox();
            this.grpMagicLevel = new System.Windows.Forms.GroupBox();
            this.rgpMaster = new System.Windows.Forms.RadioButton();
            this.rgpAdapt = new System.Windows.Forms.RadioButton();
            this.rgpNovice = new System.Windows.Forms.RadioButton();
            this.grpMagicType = new System.Windows.Forms.GroupBox();
            this.rgpBlood = new System.Windows.Forms.RadioButton();
            this.rgpNecro = new System.Windows.Forms.RadioButton();
            this.rgpTrans = new System.Windows.Forms.RadioButton();
            this.rgpAlchemy = new System.Windows.Forms.RadioButton();
            this.rgpNat = new System.Windows.Forms.RadioButton();
            this.rgpHerb = new System.Windows.Forms.RadioButton();
            this.rgpArcane = new System.Windows.Forms.RadioButton();
            this.rgpSummon = new System.Windows.Forms.RadioButton();
            this.rgpElemental = new System.Windows.Forms.RadioButton();
            this.grpCharacter = new System.Windows.Forms.GroupBox();
            this.rgpWizard = new System.Windows.Forms.RadioButton();
            this.rgpTroll = new System.Windows.Forms.RadioButton();
            this.rgpGnome = new System.Windows.Forms.RadioButton();
            this.rgpGoddess = new System.Windows.Forms.RadioButton();
            this.rgpFairy = new System.Windows.Forms.RadioButton();
            this.rgpPixie = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.txtMagicName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnDelete2 = new System.Windows.Forms.Button();
            this.btnUpdate2 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.backToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.proceedToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adminToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.welcomePageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tbcPersonal.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.grpGender.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.grpMagicLevel.SuspendLayout();
            this.grpMagicType.SuspendLayout();
            this.grpCharacter.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbcPersonal
            // 
            this.tbcPersonal.Controls.Add(this.tabPage1);
            this.tbcPersonal.Controls.Add(this.tabPage2);
            this.tbcPersonal.Location = new System.Drawing.Point(35, 63);
            this.tbcPersonal.Name = "tbcPersonal";
            this.tbcPersonal.SelectedIndex = 0;
            this.tbcPersonal.Size = new System.Drawing.Size(621, 452);
            this.tbcPersonal.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Gray;
            this.tabPage1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage1.Controls.Add(this.panel2);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(613, 426);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Personal Information";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Gray;
            this.tabPage2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage2.Controls.Add(this.btnDelete2);
            this.tabPage2.Controls.Add(this.btnUpdate2);
            this.tabPage2.Controls.Add(this.panel1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(613, 426);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Magical Information";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.btnDelete);
            this.panel2.Controls.Add(this.btnUpdate);
            this.panel2.Controls.Add(this.groupBox2);
            this.panel2.Location = new System.Drawing.Point(20, 67);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(564, 261);
            this.panel2.TabIndex = 5;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.txtPSurname);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.txtDOB);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.txtPName);
            this.groupBox2.Controls.Add(this.grpGender);
            this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox2.Location = new System.Drawing.Point(23, 35);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(501, 142);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Personal Information";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name:";
            // 
            // txtPSurname
            // 
            this.txtPSurname.Location = new System.Drawing.Point(103, 55);
            this.txtPSurname.Name = "txtPSurname";
            this.txtPSurname.Size = new System.Drawing.Size(138, 20);
            this.txtPSurname.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Surname:";
            // 
            // txtDOB
            // 
            this.txtDOB.Location = new System.Drawing.Point(103, 82);
            this.txtDOB.Name = "txtDOB";
            this.txtDOB.Size = new System.Drawing.Size(138, 20);
            this.txtDOB.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Date of Birth:";
            // 
            // txtPName
            // 
            this.txtPName.Location = new System.Drawing.Point(103, 26);
            this.txtPName.Name = "txtPName";
            this.txtPName.Size = new System.Drawing.Size(138, 20);
            this.txtPName.TabIndex = 6;
            // 
            // grpGender
            // 
            this.grpGender.Controls.Add(this.rgpMale);
            this.grpGender.Controls.Add(this.rgpFemale);
            this.grpGender.Location = new System.Drawing.Point(329, 22);
            this.grpGender.Name = "grpGender";
            this.grpGender.Size = new System.Drawing.Size(77, 77);
            this.grpGender.TabIndex = 5;
            this.grpGender.TabStop = false;
            this.grpGender.Text = "Gender";
            // 
            // rgpMale
            // 
            this.rgpMale.AutoSize = true;
            this.rgpMale.Location = new System.Drawing.Point(6, 28);
            this.rgpMale.Name = "rgpMale";
            this.rgpMale.Size = new System.Drawing.Size(48, 17);
            this.rgpMale.TabIndex = 3;
            this.rgpMale.TabStop = true;
            this.rgpMale.Text = "Male";
            this.rgpMale.UseVisualStyleBackColor = true;
            // 
            // rgpFemale
            // 
            this.rgpFemale.AutoSize = true;
            this.rgpFemale.Location = new System.Drawing.Point(6, 51);
            this.rgpFemale.Name = "rgpFemale";
            this.rgpFemale.Size = new System.Drawing.Size(59, 17);
            this.rgpFemale.TabIndex = 4;
            this.rgpFemale.TabStop = true;
            this.rgpFemale.Text = "Female";
            this.rgpFemale.UseVisualStyleBackColor = true;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(61, 208);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(165, 37);
            this.btnUpdate.TabIndex = 10;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(352, 208);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(165, 37);
            this.btnDelete.TabIndex = 11;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(15, 6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(582, 385);
            this.panel1.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.pictureBox1.BackgroundImage = global::Project.Properties.Resources.tink;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(412, 6);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(152, 365);
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.rtxtDescription);
            this.groupBox3.Controls.Add(this.grpMagicLevel);
            this.groupBox3.Controls.Add(this.grpMagicType);
            this.groupBox3.Controls.Add(this.grpCharacter);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.txtMagicName);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox3.Location = new System.Drawing.Point(13, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(393, 369);
            this.groupBox3.TabIndex = 10;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Magical Character";
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // rtxtDescription
            // 
            this.rtxtDescription.Location = new System.Drawing.Point(126, 165);
            this.rtxtDescription.Name = "rtxtDescription";
            this.rtxtDescription.Size = new System.Drawing.Size(251, 78);
            this.rtxtDescription.TabIndex = 16;
            this.rtxtDescription.Text = "";
            // 
            // grpMagicLevel
            // 
            this.grpMagicLevel.Controls.Add(this.rgpMaster);
            this.grpMagicLevel.Controls.Add(this.rgpAdapt);
            this.grpMagicLevel.Controls.Add(this.rgpNovice);
            this.grpMagicLevel.Location = new System.Drawing.Point(13, 127);
            this.grpMagicLevel.Name = "grpMagicLevel";
            this.grpMagicLevel.Size = new System.Drawing.Size(99, 117);
            this.grpMagicLevel.TabIndex = 15;
            this.grpMagicLevel.TabStop = false;
            this.grpMagicLevel.Text = "Magic Level";
            // 
            // rgpMaster
            // 
            this.rgpMaster.AutoSize = true;
            this.rgpMaster.Enabled = false;
            this.rgpMaster.Location = new System.Drawing.Point(16, 80);
            this.rgpMaster.Name = "rgpMaster";
            this.rgpMaster.Size = new System.Drawing.Size(63, 19);
            this.rgpMaster.TabIndex = 2;
            this.rgpMaster.TabStop = true;
            this.rgpMaster.Text = "Master";
            this.rgpMaster.UseVisualStyleBackColor = true;
            // 
            // rgpAdapt
            // 
            this.rgpAdapt.AutoSize = true;
            this.rgpAdapt.Enabled = false;
            this.rgpAdapt.Location = new System.Drawing.Point(16, 55);
            this.rgpAdapt.Name = "rgpAdapt";
            this.rgpAdapt.Size = new System.Drawing.Size(56, 19);
            this.rgpAdapt.TabIndex = 1;
            this.rgpAdapt.TabStop = true;
            this.rgpAdapt.Text = "Adapt";
            this.rgpAdapt.UseVisualStyleBackColor = true;
            // 
            // rgpNovice
            // 
            this.rgpNovice.AutoSize = true;
            this.rgpNovice.Location = new System.Drawing.Point(16, 30);
            this.rgpNovice.Name = "rgpNovice";
            this.rgpNovice.Size = new System.Drawing.Size(62, 19);
            this.rgpNovice.TabIndex = 0;
            this.rgpNovice.TabStop = true;
            this.rgpNovice.Text = "Novice";
            this.rgpNovice.UseVisualStyleBackColor = true;
            // 
            // grpMagicType
            // 
            this.grpMagicType.Controls.Add(this.rgpBlood);
            this.grpMagicType.Controls.Add(this.rgpNecro);
            this.grpMagicType.Controls.Add(this.rgpTrans);
            this.grpMagicType.Controls.Add(this.rgpAlchemy);
            this.grpMagicType.Controls.Add(this.rgpNat);
            this.grpMagicType.Controls.Add(this.rgpHerb);
            this.grpMagicType.Controls.Add(this.rgpArcane);
            this.grpMagicType.Controls.Add(this.rgpSummon);
            this.grpMagicType.Controls.Add(this.rgpElemental);
            this.grpMagicType.Location = new System.Drawing.Point(13, 250);
            this.grpMagicType.Name = "grpMagicType";
            this.grpMagicType.Size = new System.Drawing.Size(365, 115);
            this.grpMagicType.TabIndex = 14;
            this.grpMagicType.TabStop = false;
            this.grpMagicType.Text = "Magic Type";
            // 
            // rgpBlood
            // 
            this.rgpBlood.AutoSize = true;
            this.rgpBlood.Location = new System.Drawing.Point(219, 28);
            this.rgpBlood.Name = "rgpBlood";
            this.rgpBlood.Size = new System.Drawing.Size(94, 19);
            this.rgpBlood.TabIndex = 11;
            this.rgpBlood.TabStop = true;
            this.rgpBlood.Text = "Blood Magic";
            this.rgpBlood.UseVisualStyleBackColor = true;
            // 
            // rgpNecro
            // 
            this.rgpNecro.AutoSize = true;
            this.rgpNecro.Location = new System.Drawing.Point(219, 53);
            this.rgpNecro.Name = "rgpNecro";
            this.rgpNecro.Size = new System.Drawing.Size(94, 19);
            this.rgpNecro.TabIndex = 10;
            this.rgpNecro.TabStop = true;
            this.rgpNecro.Text = "Necromancy";
            this.rgpNecro.UseVisualStyleBackColor = true;
            // 
            // rgpTrans
            // 
            this.rgpTrans.AutoSize = true;
            this.rgpTrans.Location = new System.Drawing.Point(219, 78);
            this.rgpTrans.Name = "rgpTrans";
            this.rgpTrans.Size = new System.Drawing.Size(100, 19);
            this.rgpTrans.TabIndex = 9;
            this.rgpTrans.TabStop = true;
            this.rgpTrans.Text = "Transmorgrify";
            this.rgpTrans.UseVisualStyleBackColor = true;
            // 
            // rgpAlchemy
            // 
            this.rgpAlchemy.AutoSize = true;
            this.rgpAlchemy.Location = new System.Drawing.Point(112, 78);
            this.rgpAlchemy.Name = "rgpAlchemy";
            this.rgpAlchemy.Size = new System.Drawing.Size(71, 19);
            this.rgpAlchemy.TabIndex = 8;
            this.rgpAlchemy.TabStop = true;
            this.rgpAlchemy.Text = "Alchemy";
            this.rgpAlchemy.UseVisualStyleBackColor = true;
            // 
            // rgpNat
            // 
            this.rgpNat.AutoSize = true;
            this.rgpNat.Location = new System.Drawing.Point(112, 53);
            this.rgpNat.Name = "rgpNat";
            this.rgpNat.Size = new System.Drawing.Size(62, 19);
            this.rgpNat.TabIndex = 7;
            this.rgpNat.TabStop = true;
            this.rgpNat.Text = "Nature";
            this.rgpNat.UseVisualStyleBackColor = true;
            // 
            // rgpHerb
            // 
            this.rgpHerb.AutoSize = true;
            this.rgpHerb.Location = new System.Drawing.Point(112, 28);
            this.rgpHerb.Name = "rgpHerb";
            this.rgpHerb.Size = new System.Drawing.Size(74, 19);
            this.rgpHerb.TabIndex = 6;
            this.rgpHerb.TabStop = true;
            this.rgpHerb.Text = "Herbalist";
            this.rgpHerb.UseVisualStyleBackColor = true;
            // 
            // rgpArcane
            // 
            this.rgpArcane.AutoSize = true;
            this.rgpArcane.Location = new System.Drawing.Point(6, 78);
            this.rgpArcane.Name = "rgpArcane";
            this.rgpArcane.Size = new System.Drawing.Size(63, 19);
            this.rgpArcane.TabIndex = 5;
            this.rgpArcane.TabStop = true;
            this.rgpArcane.Text = "Arcane";
            this.rgpArcane.UseVisualStyleBackColor = true;
            // 
            // rgpSummon
            // 
            this.rgpSummon.AutoSize = true;
            this.rgpSummon.Location = new System.Drawing.Point(6, 53);
            this.rgpSummon.Name = "rgpSummon";
            this.rgpSummon.Size = new System.Drawing.Size(93, 19);
            this.rgpSummon.TabIndex = 3;
            this.rgpSummon.TabStop = true;
            this.rgpSummon.Text = "Summoning";
            this.rgpSummon.UseVisualStyleBackColor = true;
            // 
            // rgpElemental
            // 
            this.rgpElemental.AutoSize = true;
            this.rgpElemental.Location = new System.Drawing.Point(6, 28);
            this.rgpElemental.Name = "rgpElemental";
            this.rgpElemental.Size = new System.Drawing.Size(81, 19);
            this.rgpElemental.TabIndex = 4;
            this.rgpElemental.TabStop = true;
            this.rgpElemental.Text = "Elemental";
            this.rgpElemental.UseVisualStyleBackColor = true;
            // 
            // grpCharacter
            // 
            this.grpCharacter.Controls.Add(this.rgpWizard);
            this.grpCharacter.Controls.Add(this.rgpTroll);
            this.grpCharacter.Controls.Add(this.rgpGnome);
            this.grpCharacter.Controls.Add(this.rgpGoddess);
            this.grpCharacter.Controls.Add(this.rgpFairy);
            this.grpCharacter.Controls.Add(this.rgpPixie);
            this.grpCharacter.Location = new System.Drawing.Point(174, 11);
            this.grpCharacter.Name = "grpCharacter";
            this.grpCharacter.Size = new System.Drawing.Size(204, 101);
            this.grpCharacter.TabIndex = 13;
            this.grpCharacter.TabStop = false;
            this.grpCharacter.Text = "Character Type";
            // 
            // rgpWizard
            // 
            this.rgpWizard.AutoSize = true;
            this.rgpWizard.Location = new System.Drawing.Point(104, 70);
            this.rgpWizard.Name = "rgpWizard";
            this.rgpWizard.Size = new System.Drawing.Size(63, 19);
            this.rgpWizard.TabIndex = 8;
            this.rgpWizard.TabStop = true;
            this.rgpWizard.Text = "Wizard";
            this.rgpWizard.UseVisualStyleBackColor = true;
            // 
            // rgpTroll
            // 
            this.rgpTroll.AutoSize = true;
            this.rgpTroll.Location = new System.Drawing.Point(104, 45);
            this.rgpTroll.Name = "rgpTroll";
            this.rgpTroll.Size = new System.Drawing.Size(49, 19);
            this.rgpTroll.TabIndex = 7;
            this.rgpTroll.TabStop = true;
            this.rgpTroll.Text = "Troll";
            this.rgpTroll.UseVisualStyleBackColor = true;
            // 
            // rgpGnome
            // 
            this.rgpGnome.AutoSize = true;
            this.rgpGnome.Location = new System.Drawing.Point(104, 20);
            this.rgpGnome.Name = "rgpGnome";
            this.rgpGnome.Size = new System.Drawing.Size(66, 19);
            this.rgpGnome.TabIndex = 6;
            this.rgpGnome.TabStop = true;
            this.rgpGnome.Text = "Gnome";
            this.rgpGnome.UseVisualStyleBackColor = true;
            // 
            // rgpGoddess
            // 
            this.rgpGoddess.AutoSize = true;
            this.rgpGoddess.Location = new System.Drawing.Point(6, 69);
            this.rgpGoddess.Name = "rgpGoddess";
            this.rgpGoddess.Size = new System.Drawing.Size(74, 19);
            this.rgpGoddess.TabIndex = 3;
            this.rgpGoddess.TabStop = true;
            this.rgpGoddess.Text = "Goddess";
            this.rgpGoddess.UseVisualStyleBackColor = true;
            // 
            // rgpFairy
            // 
            this.rgpFairy.AutoSize = true;
            this.rgpFairy.Location = new System.Drawing.Point(6, 44);
            this.rgpFairy.Name = "rgpFairy";
            this.rgpFairy.Size = new System.Drawing.Size(51, 19);
            this.rgpFairy.TabIndex = 5;
            this.rgpFairy.TabStop = true;
            this.rgpFairy.Text = "Fairy";
            this.rgpFairy.UseVisualStyleBackColor = true;
            // 
            // rgpPixie
            // 
            this.rgpPixie.AutoSize = true;
            this.rgpPixie.Location = new System.Drawing.Point(6, 20);
            this.rgpPixie.Name = "rgpPixie";
            this.rgpPixie.Size = new System.Drawing.Size(52, 19);
            this.rgpPixie.TabIndex = 4;
            this.rgpPixie.TabStop = true;
            this.rgpPixie.Text = "Pixie";
            this.rgpPixie.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(121, 140);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(141, 15);
            this.label6.TabIndex = 10;
            this.label6.Text = "Description of Character:";
            // 
            // txtMagicName
            // 
            this.txtMagicName.Location = new System.Drawing.Point(7, 91);
            this.txtMagicName.Name = "txtMagicName";
            this.txtMagicName.Size = new System.Drawing.Size(141, 21);
            this.txtMagicName.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 60);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(91, 15);
            this.label5.TabIndex = 9;
            this.label5.Text = "Magical Name:";
            // 
            // btnDelete2
            // 
            this.btnDelete2.Location = new System.Drawing.Point(369, 397);
            this.btnDelete2.Name = "btnDelete2";
            this.btnDelete2.Size = new System.Drawing.Size(161, 28);
            this.btnDelete2.TabIndex = 13;
            this.btnDelete2.Text = "Delete";
            this.btnDelete2.UseVisualStyleBackColor = true;
            // 
            // btnUpdate2
            // 
            this.btnUpdate2.Location = new System.Drawing.Point(78, 397);
            this.btnUpdate2.Name = "btnUpdate2";
            this.btnUpdate2.Size = new System.Drawing.Size(161, 28);
            this.btnUpdate2.TabIndex = 12;
            this.btnUpdate2.Text = "Update";
            this.btnUpdate2.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Curlz MT", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(260, 46);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(408, 36);
            this.label4.TabIndex = 1;
            this.label4.Text = "You can update / delete your account";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.optionsToolStripMenuItem,
            this.proceedToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(668, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // optionsToolStripMenuItem
            // 
            this.optionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.backToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
            this.optionsToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.optionsToolStripMenuItem.Text = "Options";
            // 
            // backToolStripMenuItem
            // 
            this.backToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.adminToolStripMenuItem,
            this.welcomePageToolStripMenuItem});
            this.backToolStripMenuItem.Name = "backToolStripMenuItem";
            this.backToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.backToolStripMenuItem.Text = "Back";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // proceedToolStripMenuItem
            // 
            this.proceedToolStripMenuItem.Name = "proceedToolStripMenuItem";
            this.proceedToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.proceedToolStripMenuItem.Text = "Proceed";
            this.proceedToolStripMenuItem.Click += new System.EventHandler(this.proceedToolStripMenuItem_Click);
            // 
            // adminToolStripMenuItem
            // 
            this.adminToolStripMenuItem.Name = "adminToolStripMenuItem";
            this.adminToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.adminToolStripMenuItem.Text = "Admin (Home)";
            this.adminToolStripMenuItem.Click += new System.EventHandler(this.adminToolStripMenuItem_Click);
            // 
            // welcomePageToolStripMenuItem
            // 
            this.welcomePageToolStripMenuItem.Name = "welcomePageToolStripMenuItem";
            this.welcomePageToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.welcomePageToolStripMenuItem.Text = "Welcome Page";
            this.welcomePageToolStripMenuItem.Click += new System.EventHandler(this.welcomePageToolStripMenuItem_Click);
            // 
            // frmEditExisting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(668, 525);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbcPersonal);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmEditExisting";
            this.Text = "frmEditExisting";
            this.Load += new System.EventHandler(this.frmEditExisting_Load);
            this.tbcPersonal.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.grpGender.ResumeLayout(false);
            this.grpGender.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.grpMagicLevel.ResumeLayout(false);
            this.grpMagicLevel.PerformLayout();
            this.grpMagicType.ResumeLayout(false);
            this.grpMagicType.PerformLayout();
            this.grpCharacter.ResumeLayout(false);
            this.grpCharacter.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tbcPersonal;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtPSurname;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtDOB;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPName;
        private System.Windows.Forms.GroupBox grpGender;
        private System.Windows.Forms.RadioButton rgpMale;
        private System.Windows.Forms.RadioButton rgpFemale;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RichTextBox rtxtDescription;
        private System.Windows.Forms.GroupBox grpMagicLevel;
        private System.Windows.Forms.RadioButton rgpMaster;
        private System.Windows.Forms.RadioButton rgpAdapt;
        private System.Windows.Forms.RadioButton rgpNovice;
        private System.Windows.Forms.GroupBox grpMagicType;
        private System.Windows.Forms.RadioButton rgpBlood;
        private System.Windows.Forms.RadioButton rgpNecro;
        private System.Windows.Forms.RadioButton rgpTrans;
        private System.Windows.Forms.RadioButton rgpAlchemy;
        private System.Windows.Forms.RadioButton rgpNat;
        private System.Windows.Forms.RadioButton rgpHerb;
        private System.Windows.Forms.RadioButton rgpArcane;
        private System.Windows.Forms.RadioButton rgpSummon;
        private System.Windows.Forms.RadioButton rgpElemental;
        private System.Windows.Forms.GroupBox grpCharacter;
        private System.Windows.Forms.RadioButton rgpWizard;
        private System.Windows.Forms.RadioButton rgpTroll;
        private System.Windows.Forms.RadioButton rgpGnome;
        private System.Windows.Forms.RadioButton rgpGoddess;
        private System.Windows.Forms.RadioButton rgpFairy;
        private System.Windows.Forms.RadioButton rgpPixie;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtMagicName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnDelete2;
        private System.Windows.Forms.Button btnUpdate2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem backToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adminToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem welcomePageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem proceedToolStripMenuItem;
    }
}