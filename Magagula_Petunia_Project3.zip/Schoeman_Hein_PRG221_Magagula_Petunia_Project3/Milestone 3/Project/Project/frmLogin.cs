﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using HelperDLL;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace Project
{
    public partial class frmLogin : Form
    {
        Thread recieveThread;
        public frmLogin()
        {
            InitializeComponent();
        }

        private void btnProceed_Click(object sender, EventArgs e)
        {
            Socket client = new Socket(AddressFamily.InterNetwork,SocketType.Stream,ProtocolType.IP);
            //IPHostEntry hostEntry = Dns.Resolve(Dns.GetHostName());
            //IPAddress ipAddress = hostEntry.AddressList[0];
            //IPEndPoint ipEndPoint;
           // client.Connect(ipEndPoint);
            client.Connect(new IPEndPoint(IPAddress.Parse("10.0.0.8", 8000));

            recieveThread = new Thread(new ParameterizedThreadStart(RecieveData));
            recieveThread.Start(client);

            
            string userName = txtUserName.Text;
            string passWord = txtPassword.Text;

            MessageClass message = new MessageClass(userName, new MagicUser());
            message.key = 1;
            client.Send(message.BinarySerializer());

            /// Sends the parameters userName and passWord to Login class to authenticate
            FileHandler handle = new FileHandler();
            frmExisting existing = new frmExisting();

            if (handle.LoginAttempt(userName , passWord) == true)
            {  
                this.Hide();
                existing.Show();
            }
            else
            {
                MessageBox.Show("Please Try again", "Login Failed",MessageBoxButtons.OK,MessageBoxIcon.Warning);

                txtUserName.Clear();
                txtPassword.Clear();
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void backToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void backToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void welcomePageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmWelcome welcome = new frmWelcome();
            this.Hide();
            welcome.Show();
        }

        private void adminToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAdmin adminForm = new frmAdmin();
            this.Hide();
            adminForm.Show();
        }

        public void RecieveData(object obj) 
        {
            Socket client = (Socket)obj;

            while (true)
            {
                byte[] buffer = new byte[1024];
                client.Receive(buffer);
                MessageClass message = (MessageClass)buffer.BinaryDeSerializer();
            }
        }

     
    }
}
