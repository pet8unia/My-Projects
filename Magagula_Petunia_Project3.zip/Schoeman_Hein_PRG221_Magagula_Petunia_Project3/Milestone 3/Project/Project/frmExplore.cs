﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Project
{
    public partial class frmExplore : Form
    {
        public frmExplore()
        {
            InitializeComponent();
        }

        private void btnAllowed_Click(object sender, EventArgs e)
        {
            frmAllowed allowedForm = new frmAllowed();
            this.Hide();
            allowedForm.Show();
        }

        private void btnForbidden_Click(object sender, EventArgs e)
        {
            frmForbidden forbiddenForm = new frmForbidden();
            this.Hide();
            forbiddenForm.Show();
        }

        private void adminToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAdmin adminForm = new frmAdmin();
            this.Hide();
            adminForm.Show();
        }

        private void welcomePageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmWelcome welcomeForm = new frmWelcome();
            this.Hide();
            welcomeForm.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }
    }
}
