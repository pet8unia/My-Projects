﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace HelperDLL
{
    public class MagicUser: Person
    {
        #region Fields
        //=======================================Fields========================================================================
        private string magicUserName;
        private string location;
        private string description;
        private string magicType;
        private string magicLevel;
        private object picture;
        //====================================================================================================================
        #endregion
       
        #region Constructors
        //======================================================Constructors===========================================================
        /// <summary>
        /// Constructor for the Magic User Class
        /// </summary>
        /// <param name="magicUserNameParam">The players magical name</param>
        /// <param name="locationParam">The location of the player</param>
        /// <param name="descriptionParam">The description of the magical player</param>
        /// <param name="magicTypeParam">The type of magic the player uses</param>
        /// <param name="magicLevelParam">The magic level that player has</param>

        public MagicUser(string magicUserNameParam, string locationParam, string descriptionParam,
            string magicTypeParam, string magicLevelParam, string name, string surname, string gender, string dob)
            : base(name, surname, gender, dob)
        {
            this.MagicUserName = magicUserNameParam;
            this.Location = locationParam;
            this.Description = descriptionParam;
            this.MagicType = magicTypeParam;
            this.MagicLevel = magicLevelParam;
        }

        public MagicUser()
        {

        }
        //==========================================================================================================================
        #endregion

        #region Properties
        //========================================================Properties========================================================
        public string MagicUserName
        {
            get { return magicUserName; }
            set { magicUserName = value; }
        }

        public string Location
        {
            get { return location; }
            set { location = value; }
        }

        public string Description
        {
            get { return description; }
            set { description = value; }
        }

        public string MagicType
        {
            get { return magicType; }
            set { magicType = value; }
        }

        public string MagicLevel
        {
            get { return magicLevel; }
            set { magicLevel = value; }
        }

        public object Picture
        {
            get { return picture; }
            set { picture = value; }
        }
        //====================================================================================================================
        #endregion

        #region Override Methods
        //======================================================Methods==========================================================
        /// <summary>
        /// Override method to check if fields contain the same value 
        /// </summary>
        /// <param name="obj"></param>
        /// <returns>Same value of field</returns>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            MagicUser mu = (MagicUser)obj;

            if ((object)mu == null)
            {
                return false;
            }

            return ((this.MagicUserName == mu.MagicUserName) &&
                (this.Location == mu.Location) && (this.Description == mu.Description)
                && (this.MagicType == mu.MagicType) && (this.MagicLevel == mu.MagicLevel));
        }

        /// <summary>
        /// Shifts the fields 
        /// </summary>
        /// <returns></returns>
        public override int GetHashCode()
        {
            return this.MagicUserName.GetHashCode() ^ this.Location.GetHashCode() ^
                this.Description.GetHashCode() ^ this.MagicType.GetHashCode() ^
                this.MagicLevel.GetHashCode();
        }

        /// <summary>
        ///  Abstract class instantiation
        /// </summary>
        /// <returns></returns>
        public override string BringBackPerson()
        {
               
            return string.Format("{0}/t{1}/t{2}/t{3}", this.MagicUserName,
                this.Location, this.Description, this.MagicType,
                this.MagicLevel);
        
        }
        //====================================================================================================================
        #endregion

        #region Methods 

        /// <summary>
        ///  Runs a select query that selects a players details
        /// </summary>
        /// <returns> A list with the selected player</returns>
        public List<MagicUser> SelectPlayerANDMagicUser() 
        {
            List<MagicUser> mPlayers = new List<MagicUser>();
            DataHandler dHandler = new DataHandler();
            DataTable dataTable = new DataTable();

            string query = "SELECT * FROM [dbo].[tblMagicUser] M inner join [dbo].[tblPlayer] P ON  P.PersonIDPK =  M.MagicIDPK ";
            dataTable = dHandler.SelectPlayer(query);

            foreach (DataRow item in dataTable.Rows)
            {
                MagicUser mU = new MagicUser(item["MagicUserName"].ToString(),item["Location"].ToString(),item["Description"].ToString(),
                                item["MagicType"].ToString(), item["MagicLevel"].ToString(),item["Name"].ToString(),item["Surname"].ToString(),
                                item["Gender"].ToString(),item["DateOfBirth"].ToString());
                mPlayers.Add(mU);
            }
            return mPlayers;
        }

        /// <summary>
        /// Runs a method that will send the stored procedures name to the data handler where the user will be inserted 
        /// </summary>
        public void InsertMagicPlayer() 
        {
            string procName = "sp_InsertMagicPlayer";
            DataHandler dHandler = new DataHandler();
            dHandler.InsertPlayer(procName);
        }

        /// <summary>
        /// Runs a method that will send the stored procedures name to the data handler where the user will be updated
        /// </summary>
        public void UpdateMagicPlayer() 
        {
            string procName = "sp_UpdateMagicPlayer";
            DataHandler dHandler = new DataHandler();
            dHandler.UpdateMagicUser(procName);
        }
        
        /// <summary>
        /// Runs a method that will send the query to the data handler  where the user will be deleted
        /// </summary>
        public void DeleteMagicPlayer() 
        {
            StringBuilder builder = new StringBuilder("DELETE [PlayerIDPK] [Name] [Surname] [Gender] [DateOfBirth] [MagicUserName] [Location] [Description] [MagicType] [MagicLevel]");
            builder.Append("FROM [dbo].[tblPlayer] P inner join [dbo].[tblMagicUser] M");
            builder.Append("ON P.PlayerIDPK = M.MagicIDPK");

            DataHandler dHandler = new DataHandler();
            dHandler.DeleteMagicUser(builder.ToString());
        }
        #endregion
    }
}
