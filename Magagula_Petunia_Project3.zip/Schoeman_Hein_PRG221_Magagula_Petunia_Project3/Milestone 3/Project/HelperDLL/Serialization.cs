﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace HelperDLL
{
    public static class Serialization
    {
        /// <summary>
        /// Serializes the stream into a byte array
        /// </summary>
        /// <param name="obj"></param>
        /// <returns> dataSerialized a byte array </returns>
        public static byte[] BinarySerializer(this object obj) 
        {
            byte[] dataSerialized = new byte[1024];
            BinaryFormatter formatter = new BinaryFormatter();
            MemoryStream stream = new MemoryStream();

            try
            {
                formatter.Serialize(stream, obj);
                dataSerialized = stream.GetBuffer();
            }
            catch (Exception)
            {
                throw;
            }
            finally { stream.Close(); }

            return dataSerialized;
        }

        public static object BinaryDeSerializer(this byte[] dataBuffer) 
        {
            BinaryFormatter formatter = new BinaryFormatter();
            MemoryStream stream = new MemoryStream();
            object obj = new object();

            try
            {
                stream = new MemoryStream();
                obj = formatter.Deserialize(stream);
            }
            catch (Exception)
            {
                throw;
            }
            finally { stream.Close(); }

            return obj;
        }
    }
}
