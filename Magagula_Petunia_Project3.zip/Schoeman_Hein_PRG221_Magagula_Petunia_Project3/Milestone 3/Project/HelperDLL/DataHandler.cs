﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace HelperDLL
{
    public class DataHandler
    {
        #region Fields
        private string connectionString;
        private DataTable dataTable;
        private SqlConnection connection;
        private SqlCommand command;
        private SqlDataAdapter dataAdapter;
        #endregion

        #region Constructors
        public DataHandler(string connectionStringParam = "default")
        {
            this.connectionString = ConfigurationManager.ConnectionStrings[connectionStringParam].ConnectionString;
        }

        public DataHandler()
        {

        }
        #endregion

        #region CRUD 


            //========================Select===========================================================================================
            public DataTable SelectPlayer(string query)
        {
            dataTable = new DataTable();

            try
            {
                connection = new SqlConnection(connectionString);

                if (connection.State != ConnectionState.Open)
                {
                    connection.Open();
                }
                command = new SqlCommand(query, connection);
                dataAdapter = new SqlDataAdapter(command);
                dataAdapter.Fill(dataTable);

                command.ExecuteNonQuery();

            }
            catch (SqlException e)
            {
                FileHandler handle = new FileHandler();
                handle.WriteToTxt(new List<string>() { e.Message });
                throw new MyEx.MyCustomException("An SQL error was found");
            }
            catch (Exception e) 
            {
                FileHandler handle = new FileHandler();
                handle.WriteToTxt(new List<string>() { e.Message });
                throw new MyEx.MyCustomException("An error was found");
            }  
            finally
            {
                connection.Close();
            }

            return dataTable;
        }

            //====================Insert===============================================================================================
            public void InsertPlayer(string procName)
            {
                try
                {
                    connection = new SqlConnection(connectionString);

                    if (connection.State != ConnectionState.Open)
                    {
                        connection.Open();
                    }

                    MagicUser magicUs = new MagicUser(); 

                        command = new SqlCommand(procName, connection);
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.Add(new SqlParameter("@Name", magicUs.Name));
                        command.Parameters.Add(new SqlParameter("@Surname", magicUs.Surname));
                        command.Parameters.Add(new SqlParameter("@Gender", magicUs.Gender));
                        command.Parameters.Add(new SqlParameter("@DateOfBirth", magicUs.Dob));
                        command.Parameters.Add(new SqlParameter("@MagicUserName", magicUs.MagicUserName));
                        command.Parameters.Add(new SqlParameter("@Location", magicUs.Location));
                        command.Parameters.Add(new SqlParameter("@Description", magicUs.Description));
                        command.Parameters.Add(new SqlParameter("@MagicType", magicUs.MagicType));
                        command.Parameters.Add(new SqlParameter("@MagicLevel", magicUs.MagicLevel));
                        

                }
                catch (SqlException e)
                {
                    FileHandler handle = new FileHandler();
                    handle.WriteToTxt(new List<string>() { e.Message });
                    throw new MyEx.MyCustomException("An SQL error was found");
                }
                catch (Exception e)
                {
                    FileHandler handle = new FileHandler();
                    handle.WriteToTxt(new List<string>() { e.Message });
                    throw new MyEx.MyCustomException("An error was found");
                }
                finally
                {
                    connection.Close();
                }
            }

            //========================Delete===========================================================================================
            public void DeleteMagicUser(string query)
            {
                try
                {
                    connection = new SqlConnection(connectionString);
                    if (connection.State != ConnectionState.Open)
                    {
                        connection.Open();
                    }

                    command = new SqlCommand(query, connection);
                    command.ExecuteNonQuery();


                }
                catch (SqlException e)
                {
                    FileHandler handle = new FileHandler();
                    handle.WriteToTxt(new List<string>() { e.Message });
                    throw new MyEx.MyCustomException("An SQL error was found");
                }
                catch (Exception e)
                {
                    FileHandler handle = new FileHandler();
                    handle.WriteToTxt(new List<string>() { e.Message });
                    throw new MyEx.MyCustomException("An error was found");
                }
                finally
                {
                    connection.Close();
                }
                
            }

            //========================Update===========================================================================================
            public void UpdateMagicUser(string procName)
            {
                try
                {
                    connection = new SqlConnection(connectionString);

                    if (connection.State != ConnectionState.Open)
                    {
                        connection.Open();
                    }

                    MagicUser magicUs = new MagicUser();

                    command = new SqlCommand(procName, connection);
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(new SqlParameter("@Name", magicUs.Name));
                    command.Parameters.Add(new SqlParameter("@Surname", magicUs.Surname));
                    command.Parameters.Add(new SqlParameter("@Gender", magicUs.Gender));
                    command.Parameters.Add(new SqlParameter("@DateOfBirth", magicUs.Dob));
                    command.Parameters.Add(new SqlParameter("@MagicUserName", magicUs.MagicUserName));
                    command.Parameters.Add(new SqlParameter("@Location", magicUs.Location));
                    command.Parameters.Add(new SqlParameter("@Description", magicUs.Description));
                    command.Parameters.Add(new SqlParameter("@MagicType", magicUs.MagicType));
                    command.Parameters.Add(new SqlParameter("@MagicLevel", magicUs.MagicLevel));

                }
                catch (SqlException e)
                {
                    FileHandler handle = new FileHandler();
                    handle.WriteToTxt(new List<string>() { e.Message });
                    throw new MyEx.MyCustomException("An SQL error was found");
                }
                catch (Exception e)
                {
                    FileHandler handle = new FileHandler();
                    handle.WriteToTxt(new List<string>() { e.Message });
                    throw new MyEx.MyCustomException("An error was found");
                }
                finally
                {
                    connection.Close();
                }
            }
        
        #endregion
    }
}
