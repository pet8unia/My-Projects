﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HelperDLL
{
    public abstract class Person
    {
        #region Fields
        //=======================================Fields========================================================================
        private string name;
        private string surname;
        private string gender;
        private string dob;
        //=====================================================================================================================
        #endregion

        #region Constructors
        //=======================================Constructors========================================================================
        public Person(string nameParam, string surnameParam, string genderParam, string dobParam)
        {
            this.Name = nameParam;
            this.Surname = Surname;
            this.Gender = genderParam;
            this.Dob = dobParam;
        }

        public Person()
        {

        }
        //=========================================================================================================================
        #endregion

        #region Properties 
        //=======================================Properties========================================================================
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string Surname
        {
            get { return surname; }
            set { surname = value; }
        }

        public string Gender
        {
            get { return gender; }
            set { gender = value; }
        }

        public string Dob
        {
            get { return dob; }
            set { dob = value; }
        }
        //=======================================================================================================================
        #endregion

        #region Override Methods
        //=======================================Methods========================================================================
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            Person p = (Person)obj;

            if ((object)p == null)
            {
                return false;
            }

            return ((this.Name == p.Name) &&
                (this.Surname == p.Surname) && (this.Gender == p.Gender)
                && (this.Dob == p.Dob));
        }

        public override int GetHashCode()
        {
            return this.Name.GetHashCode() ^ this.Surname.GetHashCode() ^ this.Gender.GetHashCode() ^ this.Dob.GetHashCode();
        }

        public abstract string BringBackPerson();
        //=========================================================================================================================
        #endregion
    }
}
