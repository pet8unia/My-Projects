﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HelperDLL
{
    public class Hunter
    {
        private double bounty;
        private int key;

        public Hunter(double bountyParam , int keyParam)
        {
            this.Bounty = bountyParam;
            this.Key = keyParam;
        }

        public Hunter()
        {

        }


        public int Key
        {
            get { return key; }
            set { key = value; }
        }
        

        public double Bounty
        {
            get { return bounty; }
            set { bounty = value; }
        }

        public override bool Equals(object obj)
        {
            if (obj == null) return false;

            Hunter h = (Hunter)obj;
            if (h == null) return false;
          
            return ((this.Bounty == h.Bounty)&&(this.Key == h.Key));
        }

        public override int GetHashCode()
        {
            return this.Bounty.GetHashCode() ^ this.Key.GetHashCode();
        }

        public override string ToString()
        {
            return string.Format("{0} {1}",Bounty,Key);
        }
    }
}
