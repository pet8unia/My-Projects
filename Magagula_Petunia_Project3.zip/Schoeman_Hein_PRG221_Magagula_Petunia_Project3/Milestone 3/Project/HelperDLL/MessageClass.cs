﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace HelperDLL
{
    [Serializable]

    enum MyMenu
    {
        PersonDetails=1 , InsertPerson , DeletePerosn , update 
    }

    public class MessageClass
    {
        private string userName;
        private MagicUser messageM;

        public int key = 0;

        public MessageClass(string userNameParam,  MagicUser messageMParam)
        {
            this.MessageM = messageMParam;
            this.UserName = userNameParam;
        }

        public MessageClass()
        {

        }

        public MagicUser MessageM
        {
            get { return messageM; }
            set { messageM = value; }
        }

        public string UserName
        {
            get { return userName; }
            set { userName = value; }
        }



        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public override string ToString()
        {
            return this.UserName + " " + MessageM.ToString();
        }


        public void GetDetailsPerson()
        {
            DataHandler dataHandler = new DataHandler();
            string query = "SELECT * FROM tblPlayer";
            DataTable dataTable = dataHandler.SelectPlayer(query);

            foreach (DataRow item in dataTable.Rows)
            {
                this.MessageM.Name = item["Name"].ToString();
                this.MessageM.Surname = item["Surname"].ToString();
                this.MessageM.Gender = item["Gender"].ToString();
                this.MessageM.Dob = item["DOB"].ToString();
            }
        }

        public void InsertDataPerson()
        {
            StringBuilder insertQeury = new StringBuilder("Insert into tblPerson ");
            insertQeury.Append("(UserName,Name,Surname,Gender,DOB) ");
            insertQeury.Append("values ");
            insertQeury.Append(string.Format("('{0}','{1}','{2}','{3}','{4}')", this.UserName, this.MessageM.Name, this.MessageM.Surname, this.MessageM.Gender, this.MessageM.Dob));

            DataHandler handler = new DataHandler();
            handler.InsertPlayer(insertQeury.ToString());
        }

        public void UpdateDataMagicUser(MagicUser magicUserToUpdate)
        {
            StringBuilder updateQeury1 = new StringBuilder("Update tblMagicUser");
            updateQeury1.Append(string.Format("Set magicUserName = '{0}' ", magicUserToUpdate.MagicUserName));
            updateQeury1.Append(string.Format("Set location= '{0}' ", magicUserToUpdate.Location));
            updateQeury1.Append(string.Format("Set description= '{0}' ", magicUserToUpdate.Description));
            updateQeury1.Append(string.Format("Set magicType= '{0}' ", magicUserToUpdate.MagicType));
            updateQeury1.Append(string.Format("Set magicLevel= '{0}' ", magicUserToUpdate.MagicLevel));
            updateQeury1.Append(string.Format("Set pictures= '{0}' ", magicUserToUpdate.Picture));


            DataHandler handler = new DataHandler();
            handler.UpdateMagicUser(updateQeury1.ToString());
        }

        public void DeleteMagicUser(MagicUser magicUserToDelete)
        {
            StringBuilder deleteQuery1 = new StringBuilder("Delete FROM tblMagicUser");
            deleteQuery1.Append(string.Format("MagicUserName ={0}", magicUserToDelete.MagicUserName));
            deleteQuery1.Append(string.Format("Location ={0}", magicUserToDelete.Location));
            deleteQuery1.Append(string.Format("Description ={0}", magicUserToDelete.Description));
            deleteQuery1.Append(string.Format("MagicType ={0}", magicUserToDelete.MagicType));
            deleteQuery1.Append(string.Format("MagicLevel ={0}", magicUserToDelete.MagicLevel));
            deleteQuery1.Append(string.Format("Picture ={0}", magicUserToDelete.Picture));

            DataHandler handler = new DataHandler();
            handler.DeleteMagicUser(deleteQuery1.ToString());

        }


        public void QueriesInitailize(int num) 
        {
            MyMenu menu = (MyMenu)num;

            switch (menu)
            {
                case MyMenu.PersonDetails:
                    GetDetailsPerson();
                    break;
                case MyMenu.InsertPerson:
                    InsertDataPerson();
                    break;
                case MyMenu.DeletePerosn:
                    break;
                case MyMenu.update:
                    break;
                default:
                    break;
            }
        }

    }
}
