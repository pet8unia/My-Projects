﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HelperDLL
{
    public class Login
    {
        #region Fields
        private string userName;
        private string passWord;
        #endregion

        #region Constructors
        public Login(string userNameParam, string passWordParam)
            : base()
        {
            this.UserName = userNameParam;
            this.PassWord = passWordParam;
        }

        public Login()
        {

        }
        #endregion
        
        #region Properties
        public string PassWord
        {
            get { return passWord; }
            set { passWord = value; }
        }
        

        public string UserName
        {
            get { return userName; }
            set { userName = value; }
        }
        #endregion

        #region Override Methods
        public override bool Equals(object obj)
        {
            if (obj == null) return false;

            Login lg = (Login)obj;

            if ((object)lg == null) return false;
           
            return ((this.UserName == lg.UserName) && (this.PassWord == lg.PassWord));
        }

        public override int GetHashCode()
        {
            return this.UserName.GetHashCode() ^ this.PassWord.GetHashCode();
        }

        public override string ToString()
        {
            return string.Format("UserName: {0} PassWord: {1}",this.UserName,this.PassWord);
        }

        #endregion

        #region Methods 

        /// <summary> [PETUNIA]
        /// This method generates a new users username and password 
        /// </summary>
        /// <param name="name"></param>
        /// <param name="surname"></param>
        /// <returns> generated username and generated password to user</returns>
        public  string GenerateUsernameANDPassword(string name ,string surname)
        {
            string generatedUserName , generatedPassword;
            Random rand = new Random();

            generatedUserName = name.Substring(0, 3) + surname.Substring(0, 1) + rand.Next(0, 8000).ToString();
            generatedPassword = rand.Next(0, 9000).ToString();

            string userData = generatedUserName + "," + generatedPassword;

            List<string> data = new List<string>();
            data.Add(userData);

            FileHandler fHandler = new FileHandler("Login.txt");
            fHandler.WriteToTxt(data);

            return string.Format("These are your login details. Username: {0} Password: {1}",generatedUserName,generatedPassword); 

        }
        #endregion
    }
}
